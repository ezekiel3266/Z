BUILD THE APK (no installs needed)
1. Create a free GitHub account, make a new repository, upload everything in this folder
   (keep the .github folder). 
2. Open the Actions tab > "Build APK" > Run workflow.
3. When it finishes (~3 min), open the run and download the "ZLauncher-apk" artifact (zip, contains the .apk).
4. Copy the APK to the Android device and install it (allow "Install unknown apps").

Or in Android Studio: File > Open this folder > Build > Build APK(s).
